#include "interface/mmal/mmal.h"
#include "interface/mmal/mmal_buffer.h"
#include "interface/mmal/util/mmal_default_components.h"
#include "interface/mmal/util/mmal_util.h"
#include "interface/mmal/util/mmal_util_params.h"
#include "interface/mmal/util/mmal_connection.h"
#include <stdbool.h>

struct rawcam_interface {
  MMAL_PARAMETER_CAMERA_RX_CONFIG_T rx_cfg;
  MMAL_PARAMETER_CAMERA_RX_TIMING_T rx_timing;
  int camera_num;
  int buffer_num;
  int buffer_size;
  int running;
  int eventfd;
};

struct rawcam_interface *rawcam_init (void);
bool rawcam_start(void);
MMAL_BUFFER_HEADER_T *rawcam_buffer_get(void);
unsigned int rawcam_buffer_count(void);
void rawcam_buffer_free(MMAL_BUFFER_HEADER_T *buffer);
void rawcam_stop(void);
void rawcam_free(void);
