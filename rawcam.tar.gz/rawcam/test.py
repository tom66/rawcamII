#!/usr/bin/env python3
import numpy
import rawcam
import random
rc = rawcam.init() # initializes camera interface, returns config object
#rc.pack = rawcam.Pack.NONE
#rc.unpack = rawcam.Unpack.NONE
rawcam.start()

while True: # FIXME
    for i in range(rawcam.buffer_count()):
        buf = rawcam.buffer_get()
        #print ("got buf %s, len=%d" % (buf,len(buf)))

        arr=numpy.frombuffer(buf,dtype='uint8') # yes this is zerocopy
        print ("average sample value %d" % (arr.sum()/len(arr)))

        if random.randrange(1000)==537: # my lucky number
            open("dump.bin","wb").write(buf)

        # do other stuff with buffer contents

        rawcam.buffer_free(buf)
        
