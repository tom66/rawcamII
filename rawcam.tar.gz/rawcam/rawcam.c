#define _GNU_SOURCE
#include <ctype.h>
#include <fcntl.h>
//#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/eventfd.h>

#include "interface/vcos/vcos.h"
#include "bcm_host.h"

//#include "scope.h"
#include "interface/mmal/mmal.h"
#include "interface/mmal/mmal_buffer.h"
#include "interface/mmal/util/mmal_default_components.h"
#include "interface/mmal/util/mmal_util.h"
#include "interface/mmal/util/mmal_util_params.h"
#include "interface/mmal/util/mmal_connection.h"

#include <sys/ioctl.h>
#include <stdbool.h>
//#include "raw_header.h"
#include "rawcam.h"

struct rawcam_interface_private {
	MMAL_PARAMETER_CAMERA_RX_CONFIG_T rx_cfg;
	MMAL_PARAMETER_CAMERA_RX_TIMING_T rx_timing;
	int camera_num;
	int buffer_num;
	int buffer_size;
	int running;
	int eventfd;
	MMAL_PORT_T *output;
	MMAL_POOL_T *pool;
	MMAL_COMPONENT_T *rawcam, *isp;
	MMAL_CONNECTION_T *rawcam_isp;
	MMAL_QUEUE_T *queue;
} r = {
	.camera_num = 1,
	.running = 0,
	.eventfd = -1,
	.output = NULL,
	.rawcam = NULL,
	.isp = NULL,
	.rawcam_isp = NULL,
	.queue = NULL
};

enum teardown { NONE=0, PORT, POOL, C1, C2 };

#define WARN(x) fprintf(stderr, x "\n");
#if 0
#define DBG(x) WARN("[" x "]");
#else
#define DBG(x)
#endif

/* abort if non-zero (!= MMAL_SUCCESS) */
#define TRY(f,td) do {			      \
		DBG("[" #f "]");	      \
		if ((f)) {		      \
			WARN(#f " failed");   \
			teardown(td);	      \
			return false;	      \
		}} while(0)

static void poke_efd(uint64_t u) {
	//fprintf(stderr,"poking...");
	write(r.eventfd, &u, sizeof u);
	//fprintf(stderr,"poked\n");
}

void signal_abort(int i) {
        r.running = 0;
        write(2, "aborting\n", 9);
	poke_efd (1);
}

static void teardown(int what) {
	switch (what) {
	case PORT:
	  //if (cfg.capture)
	  mmal_port_disable(r.output);
	/* fall-through */
	case POOL:
	if (r.pool)
		mmal_port_pool_destroy(r.output, r.pool);
	if (r.rawcam_isp)	{
		mmal_connection_disable(r.rawcam_isp);
		mmal_connection_destroy(r.rawcam_isp);
	}
	/* fall-through */
	case C1:
		mmal_component_disable(r.isp);
		mmal_component_disable(r.rawcam);
	/* fall-through */
	case C2:
	if (r.rawcam)
		mmal_component_destroy(r.rawcam);
	if (r.isp)
		mmal_component_destroy(r.isp);
	}
}

void rawcam_stop (void) {
	r.running = 0;
	teardown(PORT);
}

static void callback(MMAL_PORT_T *port, MMAL_BUFFER_HEADER_T *buffer) {
	//fprintf(stderr,"queueing buffer %p (data %p, len %d)\n", buffer, buffer->data, buffer->length);
	mmal_queue_put(r.queue, buffer);
	poke_efd (1);
}

MMAL_BUFFER_HEADER_T *rawcam_buffer_get(void) {
	MMAL_BUFFER_HEADER_T *buffer = mmal_queue_get(r.queue);
	//fprintf(stderr,"dequeueing buffer %p (data %p, len %d)\n", buffer, buffer->data, buffer->length);
	return buffer;
}

unsigned int rawcam_buffer_count(void) {
	return mmal_queue_length (r.queue);
}

void rawcam_buffer_free(MMAL_BUFFER_HEADER_T *buffer) {
	//fprintf(stderr, "buffer_free called with %p\n", buffer);
	buffer->length = 0;
	mmal_port_send_buffer(r.output, buffer);
	mmal_buffer_header_release(buffer);
}

bool do_init(void) {
	TRY (!(r.eventfd = eventfd(0, 0)), NONE);
	bcm_host_init();
	TRY (mmal_component_create("vc.ril.rawcam", &r.rawcam), NONE);
	TRY (mmal_component_create("vc.ril.isp", &r.isp), C2);
	TRY (mmal_component_enable(r.rawcam), C2);
	TRY (mmal_component_enable(r.isp), C2);
	r.output = r.rawcam->output[0];
	r.rx_cfg.hdr = (MMAL_PARAMETER_HEADER_T){ .id=MMAL_PARAMETER_CAMERA_RX_CONFIG, .size=sizeof r.rx_cfg };
	r.rx_timing.hdr = (MMAL_PARAMETER_HEADER_T){ .id=MMAL_PARAMETER_CAMERA_RX_TIMING, .size=sizeof r.rx_timing };
        TRY(mmal_port_parameter_get(r.output, &r.rx_cfg.hdr), C2);
        TRY(mmal_port_parameter_get(r.output, &r.rx_timing.hdr), C2);
	r.buffer_num =  r.output->buffer_num;
	r.buffer_size = r.output->buffer_size;

	return true;
}

struct rawcam_interface *rawcam_init (void) {
	return (do_init() ? (struct rawcam_interface *)&r : NULL);
}

bool rawcam_start(void) {
	TRY (mmal_port_parameter_set_int32(r.output, MMAL_PARAMETER_CAMERA_NUM, r.camera_num), C2);
	TRY (mmal_port_parameter_set(r.output, &r.rx_cfg.hdr), C2);
	TRY (mmal_port_parameter_set(r.output, &r.rx_timing.hdr), C2);
        TRY (mmal_port_format_commit(r.output), C2);
	TRY (mmal_port_parameter_set_boolean(r.output, MMAL_PARAMETER_ZERO_COPY, MMAL_TRUE), C1);
	TRY (!(r.pool = mmal_port_pool_create(r.output, r.buffer_num, r.buffer_size)), C1);
	TRY (mmal_port_enable(r.output, callback), POOL);

	r.queue = mmal_queue_create();
	r.running = 1;
	for(int i = 0; i<r.output->buffer_num; i++) {
		MMAL_BUFFER_HEADER_T *buffer;
		TRY (!(buffer = mmal_queue_get(r.pool->queue)), PORT);
		TRY (mmal_port_send_buffer(r.output, buffer), PORT);
	}


	//signal(SIGINT, signal_abort);
	//signal(SIGQUIT, signal_abort);
	atexit (rawcam_stop);

	return true;
}

void rawcam_free(void) {
	/* FIXME */
}
